package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.ByteArrayOutputStream;

public class Camera extends AppCompatActivity {
    ImageView imageView;
    Button button, btn_post;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    EditText et_leaf, et_width, et_height;
    private FusedLocationProviderClient fusedLocationClient;
    double lat,lon;
    byte[] byteArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        getLocation();

        imageView = (ImageView) findViewById(R.id.img_camera);
        button = (Button) findViewById(R.id.take_photo_camera);
        btn_post = findViewById(R.id.post_btn);
        btn_post.setVisibility(View.GONE);
        et_height = findViewById(R.id.et_height);
        et_width = findViewById(R.id.et_width);
        et_leaf = findViewById(R.id.et_leaf);


        et_height.setVisibility(View.GONE);
        et_width.setVisibility(View.GONE);
        et_leaf.setVisibility(View.GONE);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (intent.resolveActivity(getPackageManager()) != null) {

                    startActivityForResult(intent, 1);
                }
            }
        });

        btn_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TreePost.class);
                intent.putExtra("height",et_height.getText().toString());
                intent.putExtra("width",et_width.getText().toString());
                intent.putExtra("leaf",et_leaf.getText().toString());
                intent.putExtra("lat",String.valueOf(lat));
                intent.putExtra("lon",String.valueOf(lon));
                intent.putExtra("uri",byteArray);
                startActivity(intent);
            }
        });



    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

            super.onActivityResult(requestCode, resultCode, data);
            if(resultCode ==-1){
                btn_post.setVisibility(View.VISIBLE);
                button.setVisibility(View.GONE);
                et_height.setVisibility(View.VISIBLE);
                et_width.setVisibility(View.VISIBLE);
                et_leaf.setVisibility(View.VISIBLE);
            }

        Log.e("TAG", "onActivityResult: "+data.getExtras().get("data") );

            Bitmap bitmap = (Bitmap) data.getExtras().get("data");

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byteArray = stream.toByteArray();
            imageView.setImageBitmap(bitmap);
        }

     private void getLocation(){
         if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
             // TODO: Consider calling
             //    Activity#requestPermissions
             // here to request the missing permissions, and then overriding
             //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
             //                                          int[] grantResults)
             // to handle the case where the user grants the permission. See the documentation
             // for Activity#requestPermissions for more details.
             return;
         }
         fusedLocationClient.getLastLocation()
                 .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                     @Override
                     public void onSuccess(Location location) {
                         // Got last known location. In some rare situations this can be null.
                         if (location != null) {
                             // Logic to handle location object
                             lat =location.getLatitude();
                             lon = location.getLongitude();
                         }
                     }
                 });

     }

    }




