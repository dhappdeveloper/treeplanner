package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ScrollView;

public class Donate_Tree extends AppCompatActivity implements View.OnClickListener {

    ImageView profile, support,scanner,notification,donate_tree;
    Button button1,button2,button3,button4;

    ScrollView scrollView;
    CardView cardView1,cardView2,getCardView3,getCardView4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate__tree);

        profile=(ImageView)findViewById(R.id.profile_donate_tree);
        support=(ImageView)findViewById(R.id.support_donate_tree);
        scanner=(ImageView)findViewById(R.id.qr_code_donate_tree);
        notification=(ImageView)findViewById(R.id.notification_donate_tree);
        donate_tree=(ImageView)findViewById(R.id.donate_tree_donate);
        button1=(Button) findViewById(R.id.button1_donate_tree);
        button2=(Button) findViewById(R.id. button2_donate_tree);
        button3=(Button) findViewById(R.id.button3_donate_tree);
        button4=(Button) findViewById(R.id.button4_donate_tree);
        scrollView=(ScrollView) findViewById(R.id.scroll_view_donate_tree);
        cardView1=(CardView) findViewById(R.id.cardview1_donate_tree);


        //implement Click Listener

        cardView1.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        Intent i;

        switch (view.getId()){

            case R.id.cardview1_donate_tree : i = new Intent(this,Donate_Tree_Second_Activity.class);startActivities(i);break;
             default:break;

        }


    }

    private void startActivities(Intent i) {
    }
}
