package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Donate_Tree_Second_Activity extends AppCompatActivity {

    Spinner spinner1,spinner2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate__tree__second);

        spinner1 = findViewById(R.id.category_donate_tree2);

        List<String> categories= new ArrayList<>();
        categories.add("In tribute of someone");
        categories.add("for environment");



        ArrayAdapter<String> support_adapter;
        support_adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,categories);

        support_adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        spinner1.setAdapter(support_adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                if (parent.getItemAtPosition(position).equals("why you want to plant tree?")) ;



                else

                {

                    String item =parent.getItemAtPosition(position).toString();


                    Toast.makeText(parent.getContext(),"selected :" +item,Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinner2 = findViewById(R.id.hear_about_us);

        List<String> categories2= new ArrayList<>();
        categories2.add("By internet");
        categories2.add("By people");
        categories2.add("Other");



        ArrayAdapter<String> support_adapter2;
        support_adapter2 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,categories2);

        support_adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        spinner2.setAdapter(support_adapter2);

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                if (parent.getItemAtPosition(position).equals("why you want to plant tree?")) ;



                else

                {

                    String item =parent.getItemAtPosition(position).toString();


                    Toast.makeText(parent.getContext(),"selected :" +item,Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}
