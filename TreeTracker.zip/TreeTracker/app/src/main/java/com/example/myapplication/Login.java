package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.r0adkll.slidr.Slidr;

public class Login extends Activity {
    ImageView treelogo;
    TextView name,forget,signup;
    EditText email3,password3;
    Button login3 ;
    private int counter = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Slidr.attach(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Hide the Title bar of this activity screen
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);


        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        treelogo=(ImageView)findViewById(R.id.treelogo3);
        name=(TextView)findViewById(R.id.name);
        email3=(EditText)findViewById(R.id.email3);
        password3=(EditText)findViewById(R.id.password3);
        login3=(Button)findViewById(R.id.login3);

        signup=(TextView) findViewById(R.id.noaccount);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Login.this, Sign_up.class);
                startActivity(i);
            }
        });

        forget=(TextView) findViewById(R.id.forgetpassword);
        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Login.this,forgotpassword.class);
                startActivity(i);

            }
        });





        login3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(email3.getText().toString(),password3.getText().toString());
            }
        });
    }

    private void validate(String email,String password){
        if ((email.equals("Admin"))&& (password.equals("12345"))){
            Intent intent=new Intent(Login.this, MyHome2.class);
            startActivity(intent);
        }
        else {

            counter--;


            if(counter==0){
                login3.setEnabled(false);
            }


        }
    }
    }

