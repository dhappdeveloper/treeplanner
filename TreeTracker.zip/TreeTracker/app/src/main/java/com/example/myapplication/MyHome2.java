package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.renderscript.Int4;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MyHome2 extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;

    NavigationView navigationView;

    Spinner spinner;

    Fragment fragment;

    BottomNavigationView bottomNavigationView;

    Button treeButton, nurseryButton, donate_tree_button;

    TextView view_all_first, View_all_second, featured_nursery, tree_recommended;
    Boolean isFragment = false;

    private String[] PERMISSIONS = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA};
    private int PERMISSION_ALL = 1;

    ImageView profile, scan, notification, support, treeTracker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_home2);

        Toolbar toolbar = findViewById(R.id.drawer_toolbar_nevigation);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.nevigation_drawer_layout);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorLimeGreen)));
        getSupportActionBar().setTitle("");


        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


        bottomNavigationView = findViewById(R.id.bottomnevigation12);
        navigationView = findViewById(R.id.drawer_navigation_view_home);




        view_all_first = (TextView) findViewById(R.id.viewall_home);
        View_all_second = (TextView) findViewById(R.id.viewall2_home);
        featured_nursery = (TextView) findViewById(R.id.featured_nursery_home);
        tree_recommended = (TextView) findViewById(R.id.tree_recommended_home);


//        profile=(ImageView)findViewById(R.id.profile_home);
//        scan=(ImageView)findViewById(R.id.qr_code_home);
//        notification=(ImageView)findViewById(R.id.notification_home);
//        support=(ImageView)findViewById(R.id.support_home);
        treeTracker = (ImageView) findViewById(R.id.treetracker_home);
        treeButton = (Button) findViewById(R.id.tree1_home);
        nurseryButton = (Button) findViewById(R.id.nursery_home);
        donate_tree_button = (Button) findViewById(R.id.donatetree_home_image);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                Fragment fragment=null;


                if (id == R.id.tree_menu) {
                    Intent tree = new Intent(getApplicationContext(), Tree.class);
                    startActivity(tree);
                    isFragment = false;
                    bottomNavigationView.setVisibility(View.VISIBLE);
                }

                else if (id== R.id.scaneobject) {

//                    Intent scan = new Intent(getApplicationContext(), Scanner.class);
//                    startActivity(scan);
                }

                else if (id==R.id.nursery_menu) {

                    Intent nursery = new Intent(getApplicationContext(), Nursery.class);
                    startActivity(nursery);
                    isFragment = false;
                }

                else if  (id==R.id.donate_tree_menu) {
                    Intent donateTree = new Intent(getApplicationContext(), Donate_Tree.class);
                    startActivity(donateTree);
                    isFragment = false;
                }


                else if (id==R.id.post_menu) {
                    fragment = new fragement2();
                    isFragment = true;
                }



                else if (id==R.id.view_all_post_menu) {
                    fragment = new fragement2();
                    isFragment = true;
                }

                else if (id==R.id.following_menu) {
                    Intent following = new Intent(getApplicationContext(), Social_Media_following.class);
                    startActivity(following);
                    isFragment = false;
                }
                else if (id==R.id.track_menu) {
                    Intent following = new Intent(getApplicationContext(), Camera.class);
                    startActivity(following);
                    isFragment = false;
                }

                else if (id==R.id.support_menu){
                    Intent support=new Intent(getApplicationContext(),Support_Activity.class);
                    startActivity(support);
                    isFragment = false;
                }
                else if (id == R.id.home5){
                    fragment = new fragement1();
                    isFragment = true;
                }else if (id == R.id.post5){
                    fragment = new fragement2();
                    isFragment = true;
                }else if (id == R.id.following5){
                    fragment = new fragement3();
                    isFragment = true;
                }

                if(isFragment){
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.home2,fragment ).addToBackStack(null).commit();
                }




                drawerLayout.closeDrawer(GravityCompat.START);
                DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.nevigation_drawer_layout);

                return true;
            }
        });


//        notification.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(MyHome2.this, Notification.class);
//                startActivity(i);
//            }
//        });
//
//        support.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(MyHome2.this, Support_Activity.class);
//                startActivity(i);
//
//            }
//        });
//
//        treeTracker.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });


//        treeButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(MyHome2.this, Tree.class);
//                startActivity(i);
//
//            }
//        });
//
//
//      view_all_first.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i=new Intent(MyHome2.this,Tree.class);
//                startActivity(i);
//            }
//        });
//
//
//        nurseryButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i=new Intent(MyHome2.this,Nursery.class);
//                startActivity(i);
//            }
//        });
//
//        View_all_second.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i=new Intent(MyHome2.this,Nursery.class);
//                startActivity(i);
//            }
//        });


         loadfragement(new fragement1());


    }

    private void checkPermission(){
        if (!checkPermission(PERMISSIONS)) {
            ActivityCompat.requestPermissions(MyHome2.this, PERMISSIONS, PERMISSION_ALL);
        }
    }

    public boolean checkPermission(String... permission) {
        for (String permissions : permission) {
            if (ContextCompat.checkSelfPermission(MyHome2.this, permissions)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    /**
     * Callback for the result from requesting permissions. This method
     * is invoked for every call on {@link #requestPermissions(String[], int)}.
     * <p>
     * <strong>Note:</strong> It is possible that the permissions request interaction
     * with the user is interrupted. In this case you will receive empty permissions
     * and results arrays which should be treated as a cancellation.
     * </p>
     *
     * @param requestCode  The request code passed in {@link #requestPermissions(String[], int)}.
     * @param permissions  The requested permissions. Never null.
     * @param grantResults The grant results for the corresponding permissions
     *                     which is either {@link PackageManager#PERMISSION_GRANTED}
     *                     or {@link PackageManager#PERMISSION_DENIED}. Never null.
     * @see #requestPermissions(String[], int)
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



 /*   private boolean loadfragement(Fragment fragment) {


        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.home2, fragment)
                .commit();
        return true;

    }*/


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    /*    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment = null;

            switch (item.getItemId()) {

                case R.id.home5:
                    fragment = new fragement1();
                    break;

                case R.id.post5:
                    fragment = new fragement2();
                    break;

                case R.id.following5:
                    fragment = new fragement3();
                    break;
            }

            return loadfragement(fragment);


        }*/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater Inflater = getMenuInflater();
        Inflater.inflate(R.menu.simple_menu_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.qr_code_menu:
                Intent qrcode = new Intent(this, Picture_Barcode.class);
                startActivity(qrcode);
                break;
            case R.id.notification_menu:
                Intent notification = new Intent(this, Notification.class);
                startActivity(notification);
                break;
            case R.id.support_menu:
                Intent support = new Intent(this, Support_Activity.class);
                startActivity(support);
                break;
            default:
        }

        return super.onOptionsItemSelected(item);

    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;

        switch (menuItem.getItemId()) {

            case R.id.home5:
                fragment = new fragement1();
                break;

            case R.id.post5:
                fragment = new fragement2();
                break;

            case R.id.following5:
                fragment = new fragement3();
                break;
        }

        return loadfragement(fragment);
    }

    private boolean loadfragement(Fragment fragment) {


        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.home2, fragment)
                .commit();
        return true;

    }
}


