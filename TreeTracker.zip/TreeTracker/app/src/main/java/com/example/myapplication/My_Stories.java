package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class My_Stories extends AppCompatActivity {

    Button get_started;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my__stories);

        get_started=(Button)findViewById(R.id.getstarted5);

        get_started.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i=new Intent(My_Stories.this,
                        Login.class);
                //Intent is used to switch from one activity to another.

                startActivity(i);
            }
        });
    }
}
