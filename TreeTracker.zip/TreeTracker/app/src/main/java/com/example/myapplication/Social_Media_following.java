package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Social_Media_following extends AppCompatActivity {

    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;
    private static ArrayList<Social_media_data_model> data;
    static View.OnClickListener myOnClickListener;
    private static ArrayList<Integer> removedItems;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social__media_following);








        myOnClickListener = new MyOnClickListener(this);

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        data = new ArrayList<Social_media_data_model>();
        for (int i = 0; i < Social_media_mydata.nameArray.length; i++) {
            data.add(new Social_media_data_model(
                    Social_media_mydata.nameArray[i],
                    Social_media_mydata.imageArray[i],
                    Social_media_mydata.rewardArray[i],
                    Social_media_mydata.profileArray[i],
                    Social_media_mydata.likeArray[i],
                    Social_media_mydata.commentArray[i],
                    Social_media_mydata.followingArray[i],
                    Social_media_mydata.followArray[i],
                    Social_media_mydata.followerArray[i]
            ));
        }

        removedItems = new ArrayList<Integer>();

        adapter = new Social_media_Adapter(data);
        recyclerView.setAdapter(adapter);
    }


    private static class MyOnClickListener implements View.OnClickListener {

        private final Context context;

        private MyOnClickListener(Context context) {
            this.context = context;
        }

        @Override
        public void onClick(View v) {
            removeItem(v);
        }

        private void removeItem(View v) {
            int selectedItemPosition = recyclerView.getChildPosition(v);
            RecyclerView.ViewHolder viewHolder
                    = recyclerView.findViewHolderForPosition(selectedItemPosition);
            TextView textViewName
                    = (TextView) viewHolder.itemView.findViewById(R.id.name_following);
            String selectedName = (String) textViewName.getText();
            int selectedItemId = -1;
            for (int i = 0; i < Social_media_mydata.likeArray.length; i++) {
                if (selectedName.equals(Social_media_mydata.likeArray[i])) {

                }
            }
            removedItems.add(selectedItemId);
            data.remove(selectedItemPosition);
            adapter.notifyItemRemoved(selectedItemPosition);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.social_media_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == R.id.add_item) {
            //check if any items to add
            if (removedItems.size() != 0) {
                addRemovedItemToList();
            } else {
                Toast.makeText(this, "Nothing to add", Toast.LENGTH_SHORT).show();
            }
        }
        return true;
    }

    private void addRemovedItemToList() {
        int addItemAtListPosition = 3;
        data.add(addItemAtListPosition, new Social_media_data_model(
                Social_media_mydata.nameArray[removedItems.get(0)],
                Social_media_mydata.imageArray[removedItems.get(0)],
                Social_media_mydata.rewardArray[removedItems.get(0)],
                Social_media_mydata.profileArray[removedItems.get(0)],
                Social_media_mydata.likeArray[removedItems.get(0)],
                Social_media_mydata.commentArray[removedItems.get(0)],
                Social_media_mydata.followingArray[removedItems.get(0)],
                Social_media_mydata.followArray[removedItems.get(0)],
                Social_media_mydata.followerArray[removedItems.get(0)]
                ));
        adapter.notifyItemInserted(addItemAtListPosition);
        removedItems.remove(0);
    }
}
