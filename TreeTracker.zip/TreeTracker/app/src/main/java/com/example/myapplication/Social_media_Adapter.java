package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;




    public  class Social_media_Adapter extends RecyclerView.Adapter<Social_media_Adapter.MyViewHolder> {

        private ArrayList<Social_media_data_model> dataSet;

        public static class MyViewHolder extends RecyclerView.ViewHolder {

            TextView textViewName;
            ImageView imageViewIcon;
            ImageView profile;
            TextView following;
            ImageView rewards;
            ImageView comments;
            TextView follow;
            ImageView like;
            TextView follower;


            public MyViewHolder(View itemView) {
                super(itemView);
                this.textViewName = (TextView) itemView.findViewById(R.id.name_following);

                this.imageViewIcon = (ImageView) itemView.findViewById(R.id.profile_following);
                this.profile = (ImageView) itemView.findViewById(R.id.flower1_following);
                this.rewards = (ImageView) itemView.findViewById(R.id.rewards_following);
                this.like = (ImageView) itemView.findViewById(R.id.like1_following);
                this.comments = (ImageView) itemView.findViewById(R.id.comment1_following);
                this.following = (TextView) itemView.findViewById(R.id.following_follower);
                this.follow = (TextView) itemView.findViewById(R.id.follow_following);
                this.follower = (TextView) itemView.findViewById(R.id.follower_following);



            }
        }

        public Social_media_Adapter(ArrayList<Social_media_data_model> data) {
            this.dataSet = data;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent,
                                               int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.social_media_following_model, parent, false);

            view.setOnClickListener(Social_Media_following.myOnClickListener);

            MyViewHolder myViewHolder = new MyViewHolder(view);
            return myViewHolder;
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int listPosition) {

            TextView textViewName = holder.textViewName;
             TextView following=holder.following;
             ImageView like=holder.like;
            ImageView rewards=holder.rewards;
            ImageView comment=holder.comments;
            TextView follow=holder.follow;
            ImageView profile=holder.profile;
            ImageView imageViewIcon = holder.imageViewIcon;
            TextView follower=holder.follower;

            textViewName.setText(dataSet.get(listPosition).getName());
            following.setText(dataSet.get(listPosition).getFollowing());
            follow.setText(dataSet.get(listPosition).getFollow());
            like.setImageResource(dataSet.get(listPosition).getLike());
            comment.setImageResource(dataSet.get(listPosition).getImage());
           profile.setImageResource(dataSet.get(listPosition).getImage());
            comment.setImageResource(dataSet.get(listPosition).getComment());
            imageViewIcon.setImageResource(dataSet.get(listPosition).getProfile());
            follower.setText(dataSet.get(listPosition).getFollower());
        }

        @Override
        public int getItemCount() {
            return dataSet.size();
        }
    }
