package com.example.myapplication;

public class Social_media_data_model {





    String name;

    int image,rewards,profile;
    int like,comment;
    String following,follow,follower;




    public Social_media_data_model(String name,  int image, int rewards,int profile, int like,int comment, String following,String follow,String follower) {
        this.name = name;
        this.image = image;
        this.rewards = rewards;
        this.profile = profile;
        this.like = like;
        this.comment = comment;
        this.following = following;
        this.follow = follow;
        this.follower = follower;
    }


    public String getName() {
        return name;
    }

    public int getImage() {
        return image;
    }


    public int getRewards() {
        return rewards;
    }

    public int getProfile() {
        return profile;
    }

    public int getLike() {
        return like;
    }

    public int getComment() {
        return comment;
    }

    public String getFollowing() {
        return following;
    }

    public String getFollow() {
        return follow;
    }

    public String getFollower() {
        return follower;
    }


}
