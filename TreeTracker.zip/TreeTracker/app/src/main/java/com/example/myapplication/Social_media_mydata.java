package com.example.myapplication;

public class Social_media_mydata {


    static String[] nameArray = {"Name1", "Name2", "Name3", "Name4", "Name5"};
    static int[] imageArray={R.drawable.f2,R.drawable.flower1,R.drawable.f2,R.drawable.f2,R.drawable.flower1};
    static int[] rewardArray={R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp};
    static int[] profileArray={R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_circle_black_24dp};
    static Integer[] likeArray = {R.drawable.ic_thumb_up_black_24dp,R.drawable.ic_thumb_up_black_24dp,R.drawable.ic_thumb_up_black_24dp,R.drawable.ic_thumb_up_black_24dp,R.drawable.ic_thumb_up_black_24dp};
    static int[] commentArray={R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp};
    static String[] followingArray = {"following 30","following 40","following 50","following 60","following 70"};
    static String[] followArray = {"follow","follow","follow","follow","follow"};
    static String[] followerArray = {"follower 30","follower 40","follower 50","follower 60","follower 70"};


}
