package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Support_Activity extends AppCompatActivity {

     private Spinner spinner;
     ImageView mail_support_image,contact_us_support_image;
     TextView select_the_issue_type,contact_us_support,mobile_no_support,mail_support;
     EditText other_help;
     Button submit_support;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);


        mail_support_image=(ImageView)findViewById(R.id.mail_support_image);
        contact_us_support_image=(ImageView)findViewById(R.id.contact_us_support_image);
        select_the_issue_type=(TextView)findViewById(R.id.select_the_issue_type);
        contact_us_support=(TextView)findViewById(R.id.contact_us_support);
        mobile_no_support=(TextView)findViewById(R.id.mobile_no_support);
        mail_support=(TextView)findViewById(R.id.mail_support);
        other_help=(EditText)findViewById(R.id.other_support);
        submit_support=(Button)findViewById(R.id.submit_support);
        spinner = findViewById(R.id.spinner_support);

        List<String> categories= new ArrayList<>();
        categories.add("Payment Related issue");
        categories.add("Tree related issue");
        categories.add("getting trouble in tree tracking");
        categories.add("Need help for searching tree");
        categories.add("How to plant?");
        categories.add("Social Media related issue");


        ArrayAdapter<String> support_adapter;
        support_adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,categories);

        support_adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        spinner.setAdapter(support_adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                if (parent.getItemAtPosition(position).equals("Choose Problem")) ;



                else

                {

                    String item =parent.getItemAtPosition(position).toString();


                    Toast.makeText(parent.getContext(),"selected :" +item,Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



    }
}
