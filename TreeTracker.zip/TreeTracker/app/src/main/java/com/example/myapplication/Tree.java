package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class Tree extends AppCompatActivity  {



    List<Tree_Product> productList;

    //the recyclerview
    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tree);








        //getting the recyclerview from xml
        recyclerView = (RecyclerView) findViewById(R.id.recycleview1);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //initializing the productlist
        productList = new ArrayList<>();


        //adding some items to our list
        productList.add(
                new Tree_Product(
                        1,
                        "Red Rose",
                        "Red Rose",
                        4.3,
                        130,
                        R.drawable.f2));

        productList.add(
                new Tree_Product(
                        2,
                        "White Rose",
                        "Lady Palm",
                        4.3,
                        600,
                        R.drawable.flower1));

        productList.add(
                new Tree_Product(
                        3,
                        "Red Rose",
                        "White Rose",
                        4.3,
                        500,
                        R.drawable.flower1));

        //creating recyclerview adapter
        Tree_Product_Adapter adapter = new Tree_Product_Adapter(this, productList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }




}
