package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class TreePost extends AppCompatActivity {

    TextView tv_height,tv_width,tv_leaf,tv_loaction;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tree_post);

        initView();
    }

    private void initView(){
        tv_height = findViewById(R.id.tv_height);
        tv_width = findViewById(R.id.tvwidth);
        tv_leaf = findViewById(R.id.tv_leaf);
        tv_loaction = findViewById(R.id.tv_loc);
        imageView = findViewById(R.id.img);

        Intent intent = getIntent();
        tv_height.setText(intent.getStringExtra("height"));
        tv_width.setText(intent.getStringExtra("width"));
        tv_leaf.setText(intent.getStringExtra("leaf"));
        String lat = intent.getStringExtra("lat");
        String lon = intent.getStringExtra("lon");
        tv_loaction.setText(lat + " , "+lon);
        byte[] byteArray = getIntent().getByteArrayExtra("uri");
        Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        imageView.setImageBitmap(bmp);
        Log.e("TAG", "initView: "+intent.getStringExtra("uri") );
       // imageView.setImageBitmap();
    }
}
