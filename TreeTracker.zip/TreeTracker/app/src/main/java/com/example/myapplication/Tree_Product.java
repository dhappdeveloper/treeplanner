package com.example.myapplication;

public class Tree_Product {


    private static int id;
    private static String title;
    private static double price;
    private static int image;

    public Tree_Product(int id, String red_rose, String title, double v, double price, int image) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.image = image;
    }


    public int getId() {
        return id;
    }

    public static String getTitle() {
        return title;
    }


    public static double getPrice() {
        return price;
    }

    public static int getImage() {
        return image;
    }
}
