package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class View_All_Post extends AppCompatActivity {

    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;
    private static ArrayList<View_All_Post_model_Class> data;
    static View.OnClickListener myOnClickListener;
    private static ArrayList<Integer> removedItems;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view__all__post);


        myOnClickListener = new View_All_Post.MyOnClickListener(this);

        recyclerView = (RecyclerView) findViewById(R.id.recycle_view_view_all_post);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        data = new ArrayList<View_All_Post_model_Class>();
        for (int i = 0; i < View_All_Post_MyData.profileArray.length; i++) {
            data.add(new View_All_Post_model_Class(

                    View_All_Post_MyData.profileArray[i],
                    View_All_Post_MyData.rewardArray[i],
                    View_All_Post_MyData.shareArray[i],
                    View_All_Post_MyData.profilePictureArray[i],
                    View_All_Post_MyData.likeArray[i],
                    View_All_Post_MyData.viewArray[i],
                    View_All_Post_MyData.commentArray[i],
               //     View_All_Post_MyData.no_of_followingArray[i],
                //    View_All_Post_MyData.no_of_followerArray[i],
                    View_All_Post_MyData.followingArray[i],
                    View_All_Post_MyData.followerArray[i],
                    View_All_Post_MyData.followArray[i]

            ));
        }

        removedItems = new ArrayList<Integer>();

        adapter = new View_All_Post_Adaper(data);
        recyclerView.setAdapter(adapter);
    }


    private static class MyOnClickListener implements View.OnClickListener {

        private final Context context;

        private MyOnClickListener(Context context) {
            this.context = context;
        }

        @Override
        public void onClick(View v) {
           // removeItem(v);
        }

       private void removeItem(View v) {
            int selectedItemPosition = recyclerView.getChildPosition(v);
            RecyclerView.ViewHolder viewHolder
                    = recyclerView.findViewHolderForPosition(selectedItemPosition);
            TextView textViewName
                    = (TextView) viewHolder.itemView.findViewById(R.id.name_view_all_post);
            String selectedName = (String) textViewName.getText();
            int selectedItemId = -1;
            for (int i = 0; i < View_All_Post_MyData.likeArray.length; i++) {
                if (selectedName.equals(View_All_Post_MyData.likeArray[i])) {

                }
            }
            removedItems.add(selectedItemId);
            data.remove(selectedItemPosition);
            adapter.notifyItemRemoved(selectedItemPosition);
        }
    }





    private void addRemovedItemToList() {
        int addItemAtListPosition = 4;
        data.add(addItemAtListPosition, new View_All_Post_model_Class(
                View_All_Post_MyData.profileArray[removedItems.get(0)],
                View_All_Post_MyData.rewardArray[removedItems.get(0)],
                View_All_Post_MyData.shareArray[removedItems.get(0)],
                View_All_Post_MyData.profilePictureArray[removedItems.get(0)],
                View_All_Post_MyData.likeArray[removedItems.get(0)],
                View_All_Post_MyData.viewArray[removedItems.get(0)],
                View_All_Post_MyData.commentArray[removedItems.get(0)],
            //    View_All_Post_MyData.no_of_followingArray[removedItems.get(0)],
            //    View_All_Post_MyData.no_of_followerArray[removedItems.get(0)],
                View_All_Post_MyData.followingArray[removedItems.get(0)],
                View_All_Post_MyData.followerArray[removedItems.get(0)],
                View_All_Post_MyData.followArray[removedItems.get(0)]

        ));
        adapter.notifyItemInserted(addItemAtListPosition);
        removedItems.remove(0);
    }
}
