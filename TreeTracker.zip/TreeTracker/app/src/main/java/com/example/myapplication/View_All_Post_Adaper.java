package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class View_All_Post_Adaper extends RecyclerView.Adapter<View_All_Post_Adaper.MyViewHolder> {

    private ArrayList<View_All_Post_model_Class> dataSet;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView profile;
        ImageView reward;
        ImageView share;
        ImageView profilePicture;
        ImageView like;
        ImageView view;
        ImageView comment;
      //  TextView no_of_following ;
      //  TextView no_of_follower;
        TextView following;
       TextView follower;
        TextView follow;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.profile = (ImageView) itemView.findViewById(R.id.profile_view_all_post);

            this.reward = (ImageView) itemView.findViewById(R.id.rewards_view_all_post);
            this.share = (ImageView) itemView.findViewById(R.id.share_view_all_post);
            this.profilePicture = (ImageView) itemView.findViewById(R.id.flower1_view_all_post);
            this.like = (ImageView) itemView.findViewById(R.id.like1_view_all_post);
            this.view = (ImageView) itemView.findViewById(R.id.view_view_all_post);
            this.comment = (ImageView) itemView.findViewById(R.id.comment_view_all_post);
       //     this.no_of_following = (TextView) itemView.findViewById(R.id.no_of_following_view_all_post);
        //    this.no_of_follower = (TextView) itemView.findViewById(R.id.no_of_follower_view_all_post);
            this.following = (TextView) itemView.findViewById(R.id.following_view_all_post);
            this.follower = (TextView) itemView.findViewById(R.id.follower_view_all_post);
            this.follow = (TextView) itemView.findViewById(R.id.follow_view_all_post);





        }

    }


    public View_All_Post_Adaper(ArrayList<View_All_Post_model_Class> data) {
        this.dataSet = data;
    }

    @Override
    public View_All_Post_Adaper.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.view_all_post_model, parent, false);

        view.setOnClickListener(View_All_Post.myOnClickListener);

        View_All_Post_Adaper.MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        ImageView profile = holder.profile;
        ImageView reward= holder.reward;
        ImageView share=holder.share;
        ImageView profilePicture=holder.profilePicture;
        ImageView like=holder.like;
        ImageView view=holder.view;
        ImageView comment=holder.comment;
 //       TextView no_of_following=holder.no_of_following;
  //      TextView no_of_follower=holder.no_of_follower;
        TextView following = holder.following;
        TextView follower = holder.follower;
        TextView follow=holder.follow;



        profile.setImageResource(dataSet.get(position).getProfile());
        reward.setImageResource(dataSet.get(position).getReward());
        share.setImageResource(dataSet.get(position).getShare());
        profilePicture.setImageResource(dataSet.get(position).getProfilePicture());
        like.setImageResource(dataSet.get(position).getLike());
       view.setImageResource(dataSet.get(position).getView());
        comment.setImageResource(dataSet.get(position).getComment());
   //     no_of_following.ge(dataSet.get(position).getNo_of_following());
   //     no_of_follower.setText(dataSet.get(position).getNo_of_follower());
        following.setText(dataSet.get(position).getFollowing());
        follower.setText(dataSet.get(position).getFollower());
        follow.setText(dataSet.get(position).getFollow());

    }



    @Override
    public int getItemCount() {
        return dataSet.size();
    }

}


