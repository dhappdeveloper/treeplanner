package com.example.myapplication;

import com.anychart.charts.Resource;

public class View_All_Post_MyData {

    static int[] profileArray = {R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_box_black_24dp,R.drawable.ic_account_box_black_24dp};
    static int[] rewardArray = {R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp,R.drawable.ic_card_giftcard_black_24dp};
    static int[] shareArray = {R.drawable.ic_share_black_24dp,R.drawable.ic_share_black_24dp,R.drawable.ic_share_black_24dp,R.drawable.ic_share_black_24dp};
    static int[] profilePictureArray = {R.drawable.f2,R.drawable.flower1,R.drawable.f2,R.drawable.flower1};
    static int[] likeArray = {R.drawable.ic_favorite_black_24dp,R.drawable.ic_favorite_black_24dp,R.drawable.ic_favorite_black_24dp,R.drawable.ic_favorite_black_24dp};
    static int[] viewArray = {R.drawable.ic_visibility_black_24dp,R.drawable.ic_visibility_black_24dp,R.drawable.ic_visibility_black_24dp,R.drawable.ic_visibility_black_24dp};
    static int[] commentArray = {R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp,R.drawable.ic_mode_comment_black_24dp};
  //  static int[] no_of_followingArray = {11,12,13,14};
   // static int[] no_of_followerArray = {11,12,13,14};
    static String[] followingArray = {"following","following","following","following"};
    static String[] followerArray = {"follower","follower","follower","follower"};
    static String[] followArray = {"follow","follow","follow","follow"};
 //   static String[] title_of_the_postArray = {"title_of_the_post","title_of_the_post","title_of_the_post","title_of_the_post"};








}
