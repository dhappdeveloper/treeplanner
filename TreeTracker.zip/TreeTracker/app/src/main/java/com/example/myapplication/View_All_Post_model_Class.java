package com.example.myapplication;

public class View_All_Post_model_Class  {

    int profile,reward,share,profilePicture,like,view,comment;
    String following,follower,follow;

    public View_All_Post_model_Class(int profile, int reward, int share, int profilePicture, int like, int view, int comment, String following, String follower, String follow) {
        this.profile = profile;
        this.reward = reward;
        this.share = share;
        this.profilePicture = profilePicture;
        this.like = like;
        this.view = view;
        this.comment = comment;
        this.following = following;
        this.follower = follower;
        this.follow = follow;
    }

    public int getProfile() {
        return profile;
    }

    public void setProfile(int profile) {
        this.profile = profile;
    }

    public int getReward() {
        return reward;
    }

    public void setReward(int reward) {
        this.reward = reward;
    }

    public int getShare() {
        return share;
    }

    public void setShare(int share) {
        this.share = share;
    }

    public int getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(int profilePicture) {
        this.profilePicture = profilePicture;
    }

    public int getLike() {
        return like;
    }

    public void setLike(int like) {
        this.like = like;
    }

    public int getView() {
        return view;
    }

    public void setView(int view) {
        this.view = view;
    }

    public int getComment() {
        return comment;
    }

    public void setComment(int comment) {
        this.comment = comment;
    }


    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }

    public String getFollower() {
        return follower;
    }

    public void setFollower(String follower) {
        this.follower = follower;
    }

    public String getFollow() {
        return follow;
    }

    public void setFollow(String follow) {
        this.follow = follow;
    }


}
