package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import com.hololo.tutorial.library.Step;
import com.hololo.tutorial.library.TutorialActivity;

public class Welcome_Screen2 extends TutorialActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        addFragment(new Step.Builder().setTitle("This is header")
                .setContent("This is content")
                .setBackgroundColor(Color.parseColor("#ffffff")) // int background color
                .setDrawable(R.drawable.slogan1) // int top drawable
                .setSummary("This is summary")
                .build());
        addFragment(new Step.Builder().setTitle("This is header")
                .setContent("This is content")
                .setBackgroundColor(Color.parseColor("#ffffff")) // int background color
                .setDrawable(R.drawable.slogan1) // int top drawable
                .setSummary("This is summary")
                .build());
        addFragment(new Step.Builder().setTitle("This is header")
                .setContent("This is content")
                .setBackgroundColor(Color.parseColor("#ffffff")) // int background color
                .setDrawable(R.drawable.slogan1) // int top drawable
                .setSummary("This is summary")
                .build());
        addFragment(new Step.Builder().setTitle("This is header")
                .setContent("This is content")
                .setBackgroundColor(Color.parseColor("#ffffff")) // int background color
                .setDrawable(R.drawable.slogan1) // int top drawable
                .setSummary("This is summary")
                .build());
        addFragment(new Step.Builder().setTitle("This is header")
                .setContent("This is content")
                .setBackgroundColor(Color.parseColor("#ffffff")) // int background color
                .setDrawable(R.drawable.slogan1) // int top drawable
                .setSummary("This is summary")
                .build());
        addFragment(new Step.Builder().setTitle("This is header")
                .setContent("This is content")
                .setBackgroundColor(Color.parseColor("#000000")) // int background color
                .setDrawable(R.drawable.slogan1) // int top drawable
                .setSummary("This is summary")
                .build()

        );

    }


    @Override
    public void finishTutorial() {


        Intent i=new Intent(Welcome_Screen2.this,
                My_Stories.class);
        //Intent is used to switch from one activity to another.

        startActivity(i);
        //invoke the SecondActivity.

        finish();
        //the current activity will get finished.
    }


    // Your implementation

    @Override
    public void currentFragmentPosition(int position) {

    }



}

