package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Size;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import java.io.IOException;

public class activity7 extends AppCompatActivity implements View.OnClickListener {
    Button btnTakePicture, btnScanBarcode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity7);

        initViews();


    }



            private void initViews() {
                btnTakePicture = findViewById(R.id.btnTakePicture);
                btnScanBarcode = findViewById(R.id.btnScanBarcode);
                btnTakePicture.setOnClickListener(this);
                btnScanBarcode.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.btnTakePicture:
                        startActivity(new Intent(activity7.this, Picture_Barcode.class));
                        break;
                    case R.id.btnScanBarcode:
                        startActivity(new Intent(activity7.this,scanned_barcode.class));
                        break;
                }

            }
        }





