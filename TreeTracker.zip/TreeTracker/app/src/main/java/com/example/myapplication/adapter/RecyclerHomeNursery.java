package com.example.myapplication.adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.model.NurseryPojo;

import java.util.ArrayList;
import java.util.List;

public class RecyclerHomeNursery extends RecyclerView.Adapter<RecyclerHomeNursery.MyViewHolder> {


    List<NurseryPojo> list = new ArrayList<>();

    public RecyclerHomeNursery(List<NurseryPojo> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public RecyclerHomeNursery.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_fragment_layout,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerHomeNursery.MyViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
