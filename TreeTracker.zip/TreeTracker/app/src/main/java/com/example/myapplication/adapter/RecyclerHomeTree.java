package com.example.myapplication.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.model.TreePojo;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class RecyclerHomeTree extends RecyclerView.Adapter<RecyclerHomeTree.MyViewHolder> {
    @NonNull

    List<TreePojo> treePojos = new ArrayList<>();

    public RecyclerHomeTree(@NonNull List<TreePojo> treePojos) {
        this.treePojos = treePojos;
    }

    @Override
    public RecyclerHomeTree.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_tree_layout,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerHomeTree.MyViewHolder holder, int position) {
        TreePojo treePojo = treePojos.get(position);

        holder.img_tree.setImageDrawable(treePojo.getImage());
        holder.tv_name.setText(treePojo.getName());
        holder.tv_price.setText(treePojo.getPrice());
    }

    @Override
    public int getItemCount() {
        return treePojos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        CircleImageView img_tree;
        TextView tv_name,tv_price;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);


            img_tree = itemView.findViewById(R.id.img_tree);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_price = itemView.findViewById(R.id.tv_price);
        }
    }
}
