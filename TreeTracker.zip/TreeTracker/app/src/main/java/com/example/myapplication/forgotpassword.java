package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class forgotpassword extends AppCompatActivity {
    EditText reset;
    Button reset2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);


        reset=(EditText)findViewById(R.id.reset1);


        reset2=(Button)findViewById(R.id.reset2);
        reset2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(forgotpassword.this,passwordrecovery.class);
                startActivity(i);

            }
        });


    }
}
