package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapter.RecyclerHomeTree;
import com.example.myapplication.model.TreePojo;

import java.util.ArrayList;
import java.util.List;

public class fragement1 extends Fragment {
    @Nullable

    TextView tv_view_tree;
    TextView tv_view_nurserry;
    RecyclerView recyclerView_tree;
    List<TreePojo> treePojos = new ArrayList<>();
    RecyclerHomeTree recyclerHomeTree;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment_layout,null);

        initView(view);
        initListenet();
        return view;
    }

    public  void initView(View view){
        tv_view_nurserry = view.findViewById(R.id.viewall_home);
        tv_view_tree = view.findViewById(R.id.viewall2_home);
        recyclerView_tree = view.findViewById(R.id.recycler_tree);

        setRecycler();
    }

    public void setRecycler(){
        RecyclerView.LayoutManager horizontal = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false);
        recyclerView_tree.setLayoutManager(horizontal);

        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.ladypalm),"Price -100Rs only"));
        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.flower1),"Price -200Rs only"));
        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.ladypalm),"Price -100Rs only"));
        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.flower1),"Price -200Rs only"));
        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.ladypalm),"Price -100Rs only"));
        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.ladypalm),"Price -100Rs only"));
        treePojos.add(new TreePojo("Lady Palm 50% off",getContext().getResources().getDrawable(R.drawable.ladypalm),"Price -100Rs only"));

        recyclerHomeTree = new RecyclerHomeTree(treePojos);
        recyclerView_tree.setAdapter(recyclerHomeTree);


    }

    public void initListenet(){
        tv_view_tree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        tv_view_nurserry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}
