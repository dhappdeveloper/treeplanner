package com.example.myapplication.model;

import android.graphics.drawable.Drawable;

public class TreePojo {

    String name;
    Drawable image;
    String price;

    public TreePojo(String name, Drawable image, String price) {
        this.name = name;
        this.image = image;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
